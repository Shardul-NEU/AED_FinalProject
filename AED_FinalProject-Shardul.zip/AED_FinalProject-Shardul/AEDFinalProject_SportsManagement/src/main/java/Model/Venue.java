/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Shardul
 */
public class Venue {
    private String secId;
    private String secName;
    private String secPassword;
    private Long secPhone;
    private String secEmail;
    private String mainId;
    private String mainName;
    private String mainPassword;
    private Long mainPhone;
    private String mainEmail;
    private String courtName;
    private String courtNumber;
    private String courtStatus;
    private String courtHealth;

    public String getSecId() {
        return secId;
    }

    public void setSecId(String secId) {
        this.secId = secId;
    }

    public String getSecName() {
        return secName;
    }

    public void setSecName(String secName) {
        this.secName = secName;
    }

    public String getSecPassword() {
        return secPassword;
    }

    public void setSecPassword(String secPassword) {
        this.secPassword = secPassword;
    }

    public Long getSecPhone() {
        return secPhone;
    }

    public void setSecPhone(Long secPhone) {
        this.secPhone = secPhone;
    }

    public String getSecEmail() {
        return secEmail;
    }

    public void setSecEmail(String secEmail) {
        this.secEmail = secEmail;
    }

    public String getMainId() {
        return mainId;
    }

    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    public String getMainName() {
        return mainName;
    }

    public void setMainName(String mainName) {
        this.mainName = mainName;
    }

    public String getMainPassword() {
        return mainPassword;
    }

    public void setMainPassword(String mainPassword) {
        this.mainPassword = mainPassword;
    }

    public Long getMainPhone() {
        return mainPhone;
    }

    public void setMainPhone(Long mainPhone) {
        this.mainPhone = mainPhone;
    }

    public String getMainEmail() {
        return mainEmail;
    }

    public void setMainEmail(String mainEmail) {
        this.mainEmail = mainEmail;
    }

    public String getCourtName() {
        return courtName;
    }

    public void setCourtName(String courtName) {
        this.courtName = courtName;
    }

    public String getCourtNumber() {
        return courtNumber;
    }

    public void setCourtNumber(String courtNumber) {
        this.courtNumber = courtNumber;
    }

    public String getCourtStatus() {
        return courtStatus;
    }

    public void setCourtStatus(String courtStatus) {
        this.courtStatus = courtStatus;
    }

    public String getCourtHealth() {
        return courtHealth;
    }

    public void setCourtHealth(String courtHealth) {
        this.courtHealth = courtHealth;
    }
}
